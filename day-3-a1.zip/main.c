/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
int disPrimeNumber(int n);
int main() 
{
    int n1, n2, i, flag;
    printf("Enter two positive integers: ");
    scanf("%d %d", &n1, &n2);
    if (n1 > n2) 
    {
    n1 = n1 + n2;
    n2 = n1 - n2;
    n1 = n1 - n2;
    }
    printf("Prime numbers between %d and %d are: ", n1, n2);
    for (i = n1 + 1; i < n2; ++i) 
    {
        flag = disPrimeNumber(i);
        if (flag == 1) 
        {
            printf("%d ", i);
        }
    }
    return 0;
}
int disPrimeNumber(int n) 
{
  int j, flag = 1;
  for (j = 2; j <= n / 2; ++j) 
  {
    if (n % j == 0) 
    {
      flag = 0;
      break;
    }
  }
  return flag;
}