/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
void main()
{
    int sum = 0, i, len;
    char str1[100];
    printf("Enter the string : ");
    scanf("%[^\n]s", str1);
        len = strlen(str1);
    for (i = 0; i < len; i++)
    {
        sum = sum + str1[i];
    }
    printf("\nSum of all characters : %d ",sum);
}