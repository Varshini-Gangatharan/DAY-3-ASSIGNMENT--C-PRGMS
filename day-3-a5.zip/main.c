/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
int main()
{
    char str[100], result;
    int i, len;
    int max = 0;
    int freq[256] = {0};
    printf("PEnter a String:");
    fgets(str, 100, stdin);
    len = strlen(str);
    for(i = 0; i < len; i++)
    {
        freq[str[i]]++;
    }
    for(i = 0; i < len; i++)
    {
        if(max <= freq[str[i]])
        {
            max = freq[str[i]];
            result = str[i];
        }
    }
    printf("\n Maximum Occurring Character in the String %s is '%c'  %d times", str, result, max); 
    return 0;
}
