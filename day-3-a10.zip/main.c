/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
int main()
{
    char str1[100],str2[100];
    char *p1,*p2;
    printf("Enter a String : ");
    gets(str1);
    p1=str1+strlen(str1)-1;
    p2=str2;
    while(p1>=str1)
    {
       *p2=*p1;
        p2++;
        p1--;
    }
    *p2='\0';
    printf("Original String: %s\n",str1);
    printf("Reverse String: %s",str2);
    return 0;
}
